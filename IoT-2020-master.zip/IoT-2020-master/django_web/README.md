# Web application

This code setups a simple web application that runs in localhost. In *blog/templates/blog* folder you can find the html files. In *blog/views.py* there are some interesting functions to allow the system work.

# How To

To run the localhost web application:
```
python3 manage.py runserver
```

